import React from 'react';

const FootNote = () => {
	return (
		<div className='footnote'>
			{/* <strong> */}
				Created for BUAA database project, by Samuel, Eric, and JiaXian. 
			{/* </strong> */}
		</div>
	);
}

export default FootNote;