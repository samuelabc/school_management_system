This is a simple School Management System project. 
It's frontend is built using react. It's backend is bulit using express, linking to MySQL through node-odbc.